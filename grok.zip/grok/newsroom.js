let allArticles = [];
let articlesPerPage = 6;
let currentIndex = 0;

async function loadGoogleNews() {
  const rssUrl = "https://news.google.com/rss/search?q=mining&hl=en-IN&gl=IN&ceid=IN:en";
  const apiUrl = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(rssUrl)}`;

  try {
    let response = await fetch(apiUrl);
    if (!response.ok) throw new Error("Failed to fetch news");

    let data = await response.json();

    if (!data.items || data.items.length === 0) {
      document.getElementById("google-news").innerHTML =
        "<p>⚠️ No news found. Please try again later.</p>";
      return;
    }

    allArticles = data.items;
    currentIndex = 0;

    // First batch
    displayArticles();

    // Show More button
    document.getElementById("show-more").addEventListener("click", displayArticles);
  } catch (error) {
    console.error("News Load Error:", error);
    document.getElementById("google-news").innerHTML =
      "<p>⚠️ Unable to load news. Please check your internet or try later.</p>";
  }
}

function displayArticles() {
  let container = document.getElementById("google-news");

  // If reached end → restart loop (endless news)
  if (currentIndex >= allArticles.length) {
    currentIndex = 0;
  }

  let nextArticles = allArticles.slice(currentIndex, currentIndex + articlesPerPage);

  nextArticles.forEach(article => {
    let newsItem = document.createElement("div");
    newsItem.classList.add("news-card");
    newsItem.innerHTML = `
      <h3><a href="${article.link}" target="_blank">${article.title}</a></h3>
      <small>${new Date(article.pubDate).toLocaleDateString()}</small>
      <p>${article.description || "Click read more for details."}</p>
    `;
    container.appendChild(newsItem);
  });

  currentIndex += articlesPerPage;
}

document.addEventListener("DOMContentLoaded", loadGoogleNews);
