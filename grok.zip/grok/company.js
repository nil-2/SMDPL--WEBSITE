document.addEventListener("DOMContentLoaded", function() {

  const stateLocations = {
    "Jharkhand": [23.6102, 85.2799],
    "Odisha": [20.9517, 85.0985],
    "Chhattisgarh": [21.2787, 81.8661],
    "Rajasthan": [27.0238, 74.2179],
    "Madhya Pradesh": [23.4733, 77.9479],
    "Tamil Nadu": [11.1271, 78.6569],
    "Telangana": [17.9784, 79.5941]
  };

  let map;

  document.querySelectorAll('.presence-card').forEach(card => {
    card.addEventListener('click', function() {
      const state = this.innerText.trim();
      const coords = stateLocations[state];

      if(coords) {
        const mapDiv = document.getElementById('map');
        mapDiv.style.display = "block";

        if (!map) {
          map = L.map('map').setView(coords, 7);

          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
          }).addTo(map);
        } else {
          map.setView(coords, 7, { animate: true });
        }

        L.marker(coords).addTo(map)
          .bindPopup(`<b>${state}</b>`)
          .openPopup();

        setTimeout(() => {
          map.invalidateSize();
        }, 200);
      }
    });
  });

});
